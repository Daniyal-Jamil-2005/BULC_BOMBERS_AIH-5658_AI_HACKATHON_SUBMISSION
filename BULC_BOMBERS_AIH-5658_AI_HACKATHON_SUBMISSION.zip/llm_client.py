import json
import re
import os
from dotenv import load_dotenv
from groq import Groq

# Load environment variables from the .env file
load_dotenv()

# Grab the key securely from the environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise ValueError("GROQ_API_KEY is missing from the .env file!")

client = Groq(api_key=GROQ_API_KEY)
MODEL_NAME = "llama-3.3-70b-versatile"

# ─────────────────────────────────────────────────────────────────────────────
# PROMPT
# Temperature=0 for deterministic extraction.
# Combined classify + extract in one call (saves API round-trips).
# ─────────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """\
You are an expert email parser for a student opportunity assistant.
Your job is to read ONE email and output a SINGLE valid JSON object. 
DO NOT output any explanation, markdown, code fences, or extra text — ONLY the JSON.

CLASSIFICATION RULE:
- If the email does NOT contain a real opportunity (scholarship, internship, fellowship, 
  competition, hackathon, grant, admission) output exactly:
  {"is_opportunity": false}

- If it IS a genuine opportunity, extract every field below.
  Use null for any field you cannot find.

EXTRACTION SCHEMA (use exactly these keys):
{
  "is_opportunity": true,
  "type": "scholarship|internship|fellowship|competition|hackathon|grant|admission|other",
  "title": "<short title of the opportunity>",
  "org": "<organization or institution name>",
  "deadline_raw": "<the deadline string exactly as it appears in the email, e.g. 'April 30, 2025' or 'in 5 days'>",
  "eligibility": ["<criterion 1>", "<criterion 2>"],
  "required_docs": ["<document 1>", "<document 2>"],
  "link": "<application URL or null>",
  "contact": "<contact email/phone or null>",
  "min_cgpa": <minimum CGPA as a float, or null>,
  "mandatory_language": "<required language cert, e.g. 'N5 Japanese', 'IELTS 6.5', or null>",
  "degree_restrictions": ["<e.g. BSCS>", "<BBA>"],
  "graduation_year_restriction": <graduation year integer or null>,
  "location": "<Remote|Online|city name|Country|null>",
  "is_scholarship_or_grant": <true if type is scholarship or grant, else false>
}

IMPORTANT RULES:
- degree_restrictions: only fill if the email explicitly restricts to specific degrees. Leave [] if open to all.
- mandatory_language: only fill if a specific language certification is REQUIRED.
- deadline_raw: copy the EXACT deadline text from the email. If it says "in 3 days", write "in 3 days".
- is_scholarship_or_grant: set true ONLY for scholarships and grants.
- Output ONLY the JSON. No markdown. No prose.
"""

def _clean_json_response(raw: str) -> str:
    """Strip markdown fences and whitespace that LLMs sometimes add."""
    raw = raw.strip()
    # Remove ```json ... ``` or ``` ... ```
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    return raw.strip()


def extract_opportunity(email_text: str) -> dict | None:
    """
    Send one email to Groq and return the parsed dict, or None on failure.
    Retries up to 2 times with an explicit correction message.
    """
    base_user_msg = (
        f"Parse the following email and return ONLY a valid JSON object.\n\n"
        f"EMAIL:\n{email_text}"
    )
    user_msg = base_user_msg

    for attempt in range(3):  # 0, 1, 2
        try:
            response = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": user_msg},
                ],
                model=MODEL_NAME,
                temperature=0,
                max_tokens=1024,
            )
            raw_content = response.choices[0].message.content
            cleaned = _clean_json_response(raw_content)
            return json.loads(cleaned)

        except json.JSONDecodeError as exc:
            if attempt < 2:
                # Retry with a stricter correction instruction
                user_msg = (
                    f"Your previous response was not valid JSON. "
                    f"Error: {exc}. "
                    f"Output ONLY the raw JSON object — no markdown, no explanation.\n\n"
                    f"EMAIL:\n{email_text}"
                )
            else:
                print(f"[llm_client] JSON parse failed after 3 attempts: {exc}")
                return None

        except Exception as exc:
            print(f"[llm_client] API error on attempt {attempt+1}: {exc}")
            if attempt == 2:
                return None

    return None
