import re
import datetime
from dateutil.parser import parse as parse_date, ParserError
from models import StudentProfile, ExtractedOpportunity, ScoreBreakdown, ScoreDetail, ActionChecklist
from typing import List, Tuple, Optional


# ─────────────────────────────────────────────────────────────────────────────
# DATE NORMALIZATION
# Handles:
#   - Absolute dates: "April 30, 2025", "30 Apr 2025", "2025-04-30", "03/04/25"
#   - Relative dates: "in 3 days", "in 2 weeks", "in 1 month", "next Friday"
#   - Raw keyword: "tomorrow", "today"
# ─────────────────────────────────────────────────────────────────────────────

RELATIVE_PATTERNS = [
    (r"in\s+(\d+)\s+day",    lambda n: datetime.timedelta(days=int(n))),
    (r"in\s+(\d+)\s+week",   lambda n: datetime.timedelta(weeks=int(n))),
    (r"in\s+(\d+)\s+month",  lambda n: datetime.timedelta(days=int(n) * 30)),
    (r"within\s+(\d+)\s+day",lambda n: datetime.timedelta(days=int(n))),
    (r"(\d+)\s+days?\s+left", lambda n: datetime.timedelta(days=int(n))),
]

def normalize_date(date_str: Optional[str]) -> Optional[str]:
    if not date_str:
        return None

    date_str_lower = date_str.lower().strip()

    # Handle pure relative strings first
    if date_str_lower == "today":
        return datetime.date.today().isoformat()
    if date_str_lower == "tomorrow":
        return (datetime.date.today() + datetime.timedelta(days=1)).isoformat()

    for pattern, delta_fn in RELATIVE_PATTERNS:
        m = re.search(pattern, date_str_lower)
        if m:
            delta = delta_fn(m.group(1))
            return (datetime.date.today() + delta).isoformat()

    # Fall back to dateutil for absolute dates
    try:
        dt = parse_date(date_str, fuzzy=True, dayfirst=False)
        return dt.date().isoformat()
    except (ParserError, OverflowError, ValueError):
        return None


# ─────────────────────────────────────────────────────────────────────────────
# HARD DISQUALIFIERS  (applied BEFORE scoring, no points awarded)
# ─────────────────────────────────────────────────────────────────────────────

def check_hard_disqualifiers(
    profile: StudentProfile,
    opp: ExtractedOpportunity,
) -> Tuple[bool, str]:

    # 1. CGPA gate
    if opp.min_cgpa is not None and profile.cgpa < opp.min_cgpa:
        return True, f"CGPA too low ({profile.cgpa} < required {opp.min_cgpa})"

    # 2. Degree restriction
    if opp.degree_restrictions:
        profile_deg_lower = profile.degree.lower()
        matches = [
            d for d in opp.degree_restrictions
            if d.lower() in profile_deg_lower or profile_deg_lower in d.lower()
        ]
        if not matches:
            return True, (
                f"Degree '{profile.degree}' not eligible. "
                f"Requires one of: {opp.degree_restrictions}"
            )

    # 3. Mandatory language certification
    if opp.mandatory_language:
        lang_lower = opp.mandatory_language.lower()
        has_lang = any(lang_lower in s.lower() for s in (profile.skills or []))
        if not has_lang:
            return True, f"Missing mandatory language/cert: '{opp.mandatory_language}'"

    # 4. Graduation-year gate
    if opp.graduation_year_restriction is not None:
        current_year = datetime.datetime.now().year
        semesters_remaining = max(0, 8 - profile.semester)
        years_remaining = semesters_remaining / 2
        estimated_grad_year = current_year + years_remaining
        if estimated_grad_year > opp.graduation_year_restriction:
            return True, (
                f"Graduation year mismatch "
                f"(estimated {int(estimated_grad_year)}, "
                f"required by {opp.graduation_year_restriction})"
            )

    return False, ""


# ─────────────────────────────────────────────────────────────────────────────
# URGENCY SCORE  (0–30)
# ─────────────────────────────────────────────────────────────────────────────

def calculate_urgency(deadline_iso: Optional[str]) -> Tuple[int, str]:
    if not deadline_iso:
        return 5, "Deadline unknown"

    try:
        deadline_date = datetime.date.fromisoformat(deadline_iso)
        today = datetime.date.today()
        diff = (deadline_date - today).days

        if diff < 0:
            return 0, f"Deadline already passed ({deadline_iso})"
        elif diff <= 2:
            return 30, f"CRITICAL — {diff} day(s) left"
        elif diff <= 7:
            return 25, f"HIGH — {diff} days left"
        elif diff <= 14:
            return 15, f"MEDIUM — {diff} days left"
        elif diff <= 30:
            return 8, f"LOW — {diff} days left"
        else:
            return 2, f"FUTURE — {diff} days left"
    except (ValueError, TypeError):
        return 5, "Could not calculate urgency from deadline"


# ─────────────────────────────────────────────────────────────────────────────
# SCORING ENGINE  (pure deterministic, zero LLM)
# ─────────────────────────────────────────────────────────────────────────────

def score_opportunity(
    profile: StudentProfile,
    opp: ExtractedOpportunity,
    raw_email_body: str = "",
) -> ScoreBreakdown:

    # ── 1. Skill Alignment (0–40) ─────────────────────────────────────────
    # Search across title, eligibility list, AND the raw email body for maximum coverage
    searchable_text = " ".join(filter(None, [
        opp.title or "",
        " ".join(opp.eligibility or []),
        raw_email_body,
    ])).lower()

    matched_skills = [s for s in profile.skills if s.lower() in searchable_text]

    if profile.skills:
        match_ratio = len(matched_skills) / len(profile.skills)
        skill_score = int(match_ratio * 40)
        # Floor: give 5 pts if the email is an opportunity even with 0 skill matches
        if skill_score == 0:
            skill_score = 5
    else:
        skill_score = 5

    skill_reason = (
        f"Matched skills: {', '.join(matched_skills)}"
        if matched_skills
        else "No explicit skill overlap found, base score applied"
    )

    # ── 2. Urgency (0–30) ────────────────────────────────────────────────
    deadline_iso = normalize_date(opp.deadline_raw)
    urg_score, urg_reason = calculate_urgency(deadline_iso)

    # ── 3. Opportunity-type match (0–15) ─────────────────────────────────
    type_score = 0
    type_reason = "No preferred type match"
    if opp.type:
        opp_type_lower = opp.type.lower()
        exact = any(p.lower() == opp_type_lower for p in profile.preferred_opportunity_types)
        partial = any(p.lower() in opp_type_lower or opp_type_lower in p.lower()
                      for p in profile.preferred_opportunity_types)
        if exact:
            type_score = 15
            type_reason = f"Exact type match: '{opp.type}'"
        elif partial:
            type_score = 8
            type_reason = f"Partial type match: '{opp.type}'"

    # ── 4. Location alignment (0–10) ─────────────────────────────────────
    loc_score = 0
    loc_reason = "Location unknown or no preference match"
    if opp.location:
        loc_lower = opp.location.lower()
        pref_lower = profile.location_preference.lower()
        if "remote" in loc_lower or "online" in loc_lower:
            loc_score = 10
            loc_reason = "Remote / online opportunity"
        elif pref_lower in loc_lower or loc_lower in pref_lower:
            loc_score = 8
            loc_reason = f"City/region match: {opp.location}"
        elif "national" in loc_lower or "pakistan" in loc_lower:
            loc_score = 5
            loc_reason = f"National opportunity: {opp.location}"
        else:
            loc_score = 0
            loc_reason = f"International location (no bonus): {opp.location}"

    # ── 5. Financial bonus (0–5) ──────────────────────────────────────────
    fin_score = 0
    fin_reason = "No financial bonus applicable"
    if profile.financial_need and opp.is_scholarship_or_grant:
        fin_score = 5
        fin_reason = "Scholarship/grant + student has financial need"

    # ── 6. Completeness bonus (0–5) ──────────────────────────────────────
    has_deadline = bool(opp.deadline_raw)
    has_link_or_contact = bool(opp.link) or bool(opp.contact)
    has_eligibility = bool(opp.eligibility)

    fields_present = sum([has_deadline, has_link_or_contact, has_eligibility])
    if fields_present == 3:
        comp_score = 5
        comp_reason = "All key fields present (deadline, link/contact, eligibility)"
    elif fields_present >= 1:
        comp_score = 2
        comp_reason = f"Partial info ({fields_present}/3 key fields)"
    else:
        comp_score = 0
        comp_reason = "Minimal information extracted"

    total = skill_score + urg_score + type_score + loc_score + fin_score + comp_score

    return ScoreBreakdown(
        skill_alignment=ScoreDetail(score=skill_score, reason=skill_reason),
        urgency=ScoreDetail(score=urg_score, reason=urg_reason),
        type_match=ScoreDetail(score=type_score, reason=type_reason),
        location=ScoreDetail(score=loc_score, reason=loc_reason),
        financial_bonus=ScoreDetail(score=fin_score, reason=fin_reason),
        completeness=ScoreDetail(score=comp_score, reason=comp_reason),
        total=total,
    )


# ─────────────────────────────────────────────────────────────────────────────
# CHECKLIST GENERATOR
# ─────────────────────────────────────────────────────────────────────────────

def generate_checklist(opp: ExtractedOpportunity) -> List[ActionChecklist]:
    items: List[ActionChecklist] = []

    # Document tasks
    for doc in (opp.required_docs or []):
        items.append(ActionChecklist(task=f"Prepare: {doc}"))

    # Application link
    if opp.link:
        items.append(ActionChecklist(task=f"Apply via: {opp.link}"))
    elif opp.contact:
        items.append(ActionChecklist(task=f"Contact: {opp.contact}"))

    # Deadline reminder
    if opp.deadline_raw:
        items.append(ActionChecklist(task=f"Submit before deadline: {opp.deadline_raw}"))

    if not items:
        items.append(ActionChecklist(task="Review opportunity details and apply"))

    return items


# ─────────────────────────────────────────────────────────────────────────────
# URGENCY BADGE HELPER
# ─────────────────────────────────────────────────────────────────────────────

def get_urgency_badge(urgency_score: int) -> str:
    if urgency_score >= 30:
        return "CRITICAL"
    elif urgency_score >= 25:
        return "HIGH"
    elif urgency_score >= 15:
        return "MEDIUM"
    else:
        return "LOW"
