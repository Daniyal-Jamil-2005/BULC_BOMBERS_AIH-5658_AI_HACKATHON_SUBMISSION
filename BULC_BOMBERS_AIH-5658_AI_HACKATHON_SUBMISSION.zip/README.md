# VOID_COPILOT — Opportunity Inbox Copilot
## SOFTEC 2026 AI Hackathon

---

## QUICK START (2 commands)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Then open `frontend/index.html` in your browser.

---

## PROJECT STRUCTURE

```
project/
├── backend/
│   ├── main.py          ← FastAPI app, all endpoints
│   ├── engine.py        ← Deterministic scoring engine (105 pts, 6 dimensions)
│   ├── llm_client.py    ← Groq API client (llama-3.3-70b-versatile)
│   ├── models.py        ← Pydantic schemas
│   ├── test_backend.py  ← HTTP-level test runner
│   └── requirements.txt
├── frontend/
│   └── index.html       ← Complete SPA (zero build step, open directly)
├── start.py             ← One-click launcher
└── README.md
```

---

## BACKEND — API ENDPOINTS

| Method | Path          | Description                              |
|--------|---------------|------------------------------------------|
| GET    | /             | Root + endpoint map                      |
| GET    | /health       | Health check                             |
| GET    | /sample-data  | 15 sample emails + demo student profile  |
| POST   | /process      | **Main pipeline** — full scan & rank     |
| GET    | /docs         | Swagger UI (auto-generated)              |

### POST /process — Request body
```json
{
  "profile": {
    "degree": "BSCS",
    "semester": 6,
    "cgpa": 3.4,
    "skills": ["Python", "Machine Learning", "AWS"],
    "preferred_opportunity_types": ["internship", "hackathon", "scholarship"],
    "location_preference": "Lahore",
    "financial_need": true
  },
  "emails": [
    "Subject: ...\nBody...",
    "---",
    "Subject: ...\nBody..."
  ]
}
```

---

## SCORING ENGINE (105 pts max — fully deterministic, zero LLM)

| Dimension        | Max Pts | Logic                                                 |
|------------------|---------|-------------------------------------------------------|
| Skill Alignment  | 40      | % of student skills found in email body/eligibility   |
| Urgency          | 30      | CRITICAL ≤2d / HIGH ≤7d / MEDIUM ≤14d / LOW ≤30d    |
| Type Match       | 15      | Exact match=15, partial=8 vs preferred_types          |
| Location         | 10      | Remote=10, city match=8, national=5, international=0  |
| Financial Bonus  | 5       | +5 if scholarship/grant AND student has financial need |
| Completeness     | 5       | All key fields present (deadline, link, eligibility)  |

### Hard Disqualifiers (applied before scoring — INELIGIBLE)
1. CGPA too low (student CGPA < email min_cgpa)
2. Degree mismatch (email restricts to specific degrees)
3. Missing mandatory language/certification (e.g. N5 Japanese, IELTS 7.0)
4. Graduation year restriction (student won't graduate in time)

---

## FRONTEND — 4 VIEWS

| View             | Description                                          |
|------------------|------------------------------------------------------|
| SCAN_PROCESS     | Input form: student profile + email paste area       |
| SYSTEM_INTEL     | Ranked opportunity cards with expandable checklists  |
| ELIMINATED_NOISE | Log of all discarded/non-opportunity emails          |
| USER_PROFILE     | Visual summary of the active student profile         |

Each opportunity card includes:
- Urgency badge (CRITICAL / HIGH / MEDIUM / LOW)
- 6-dimension mini score bars
- Expandable checklist + score reasoning
- AUDIT_TRAIL modal with full logic trace table
- Direct APPLY_NOW link

---

## RUNNING THE TEST SUITE

With the backend running:
```bash
cd backend
python test_backend.py
```

Health-only check:
```bash
python test_backend.py --health
```

---

## API KEY

Groq API key is pre-configured in `backend/llm_client.py`.
Model: `llama-3.3-70b-versatile` at temperature=0 for deterministic extraction.

To update: edit `GROQ_API_KEY` in `backend/llm_client.py`.
