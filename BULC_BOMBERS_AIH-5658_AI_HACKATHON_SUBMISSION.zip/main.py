from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import ValidationError
from typing import List

from models import (
    ProcessRequest, ProcessResponse,
    ExtractedOpportunity,
    RankedOpportunity, DiscardedOpportunity, FailedOpportunity,
    StudentProfile,
)
from llm_client import extract_opportunity
from engine import (
    check_hard_disqualifiers,
    score_opportunity,
    generate_checklist,
    get_urgency_badge,
    normalize_date,
)

# ─────────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Opportunity Inbox Copilot",
    description="SOFTEC 2026 AI Hackathon – Email parsing + deterministic ranking",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────────────────────────────────────
# ROOT / HEALTH
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "status": "ok",
        "service": "Opportunity Inbox Copilot API",
        "version": "1.0.0",
        "endpoints": {
            "POST /process": "Process emails against a student profile",
            "GET  /sample-data": "Get 15 sample emails + demo profile for testing",
            "GET  /health": "Health check",
            "GET  /docs": "Swagger UI",
        },
    }

@app.get("/health")
def health():
    return {"status": "ok"}

# ─────────────────────────────────────────────────────────────────────────────
# SAMPLE DATA  –  15 diverse emails + demo student profile
# ─────────────────────────────────────────────────────────────────────────────

SAMPLE_EMAILS: List[str] = [
    # ── Genuine opportunities ────────────────────────────────────────────────
    """Subject: Remote Cloud Security Internship – Apply Now!
Hi there,
CloudSec Pakistan is offering a 2-month remote internship in Cloud Security.
Skills required: Python, AWS, Cloud Security, Linux.
Deadline: in 3 days. Minimum CGPA: 3.0.
Required documents: Resume, Transcript.
Apply at: https://cloudsec.pk/intern
Contact: hr@cloudsec.pk""",

    """Subject: National Cybersecurity Hackathon 2025
Dear Student,
You are invited to the National Cybersecurity Hackathon hosted by NCA Pakistan.
Open to teams of 1-3. All degrees welcome.
Location: Remote (Online).
Deadline: in 10 days.
Prize pool: PKR 500,000.
Registration: https://nca.gov.pk/hackathon
Contact: hackathon@nca.gov.pk""",

    """Subject: LUMS Merit Scholarship – Final Year Students
Dear Applicant,
LUMS is offering a full merit scholarship for exceptional final-year undergraduate students.
Required CGPA: 3.5+.
Open to: BSCS, BSEE, BSMath students only.
Deadline: April 30, 2025.
Required documents: Transcript, Two recommendation letters, Statement of Purpose.
Apply: https://lums.edu.pk/scholarship
Financial award: Full tuition + stipend. This IS a scholarship.""",

    """Subject: Google Summer of Code 2025 – Open Source Internship
Hello Developer,
Google Summer of Code (GSoC) is accepting applications from university students worldwide.
You will work on an open-source project with a mentor for 10 weeks.
Stipend: USD 1,500–3,300.
Deadline: in 30 days.
Skills preferred: Python, Machine Learning, Algorithms.
Apply at: https://summerofcode.withgoogle.com
Open to all degrees and all years.""",

    """Subject: AI Research Fellowship – Tokyo Institute of Technology
Dear Student,
Tokyo Tech is inviting applications for its AI Research Fellowship (6 months, on-site in Tokyo).
Minimum requirements: CGPA 3.5+, N5 Japanese language certification mandatory.
Deadline: in 60 days.
Required: Resume, Research proposal, Two recommendation letters, Language certificate.
Apply: https://titech.ac.jp/fellowship""",

    """Subject: Data Science Internship – Xord (Lahore)
Hi,
Xord is hiring a Data Science intern for a 3-month position at our Lahore office.
Requirements: Python, Pandas, Machine Learning basics.
CGPA requirement: 2.8 minimum.
Deadline: in 7 days.
Send your CV to: careers@xord.com""",

    """Subject: HEC Need-Based Scholarship 2025
Dear Student,
The Higher Education Commission (HEC) Pakistan is offering need-based scholarships 
to deserving undergraduate students.
Eligibility: Financial need, CGPA 2.5+, Pakistani citizen.
Award: Full tuition coverage.
Deadline: May 15, 2025.
Required documents: Income certificate, CNIC copy, Transcript, Application form.
Apply online: https://hec.gov.pk/scholarships
This is a scholarship and grant program.""",

    """Subject: Microsoft AI Skills Challenge – Win Certifications
Dear Tech Enthusiast,
Join Microsoft's AI Skills Challenge and earn free Azure AI certifications!
Open to everyone. No fees. No restrictions.
Complete learning paths online at your own pace.
Challenge period: Ends in 14 days.
Link: https://microsoft.com/ai-challenge""",

    """Subject: Devsinc Frontend Internship – React Developer Needed
Hi,
Devsinc is looking for a Frontend Intern with React.js skills.
Location: Lahore (On-site).
Duration: 2 months.
Deadline: in 5 days.
Stipend: PKR 15,000/month.
Required: Resume, GitHub profile.
Apply: https://devsinc.com/careers""",

    """Subject: PIEAS Research Grant for Final Year Projects
Dear Senior Student,
PIEAS is offering research grants for BSCS and BSEE final-year students 
working on AI or Cybersecurity projects.
Grant amount: PKR 100,000.
Must be in semester 7 or 8.
Graduation year restriction: 2026.
Deadline: in 21 days.
Required: Project proposal, Faculty endorsement letter.
Apply: research@pieas.edu.pk
This is a grant.""",

    # ── Non-opportunities (should be discarded) ──────────────────────────────
    """Subject: University Cafeteria New Menu – Try Our Special Biryani!
Hey everyone,
The university cafeteria is launching its new spring menu next Monday.
Come try our famous Dumpukht Biryani at a special introductory price.
Main campus, Block B canteen. Open 8am – 8pm.
Management""",

    """Subject: Lost: Black Backpack near CS Department
Hi,
I lost my black JanSport backpack near the CS department on Wednesday evening.
It has my laptop and notes inside. If found, please contact me at 0300-1234567.
Reward offered. Thank you.""",

    """Subject: Student Society Elections – Cast Your Vote Tomorrow!
Dear Students,
The annual FAST Student Society elections will be held tomorrow, 18th April.
Please come and vote for your class representatives.
Voting booths open 9am–3pm in the main hall.
Electoral Committee""",

    """Subject: Library Fine Reminder
Dear Student,
This is a reminder that you have an outstanding library fine of PKR 450.
Please clear this fine at the library counter before the end of the month 
to avoid account suspension.
FAST-NU Library""",

    """Subject: Seminar on Blockchain Technology – This Friday
Dear Students,
The CS Department is hosting a guest lecture on Blockchain Technology 
by Mr. Ahmed Raza (Ex-Google) this Friday at 2pm in Auditorium B.
Attendance is voluntary. Refreshments will be served.
CS Department""",
]

DEMO_PROFILE = {
    "degree": "BSCS",
    "semester": 6,
    "cgpa": 3.4,
    "skills": ["Python", "Cloud Security", "React", "Machine Learning", "AWS"],
    "preferred_opportunity_types": ["internship", "hackathon", "scholarship"],
    "location_preference": "Lahore",
    "financial_need": True,
}

@app.get("/sample-data")
def get_sample_data():
    """Returns 15 diverse sample emails and a demo student profile for frontend testing."""
    return {
        "profile": DEMO_PROFILE,
        "emails": SAMPLE_EMAILS,
        "email_count": len(SAMPLE_EMAILS),
        "note": "Mix of real opportunities and non-opportunities for demo purposes.",
    }

# ─────────────────────────────────────────────────────────────────────────────
# MAIN PIPELINE:  POST /process
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/process", response_model=ProcessResponse)
def process_emails(request: ProcessRequest):
    """
    Full pipeline:
    1. LLM: classify + extract each email (with 2-retry fallback)
    2. Validation: schema validation via Pydantic
    3. Hard disqualifiers: CGPA, degree, language, graduation year
    4. Scoring: 6-dimension deterministic engine (105 pts max)
    5. Checklist: dynamic from extracted required_docs
    6. Sort by total score descending
    """
    if not request.emails:
        raise HTTPException(status_code=400, detail="No emails provided.")

    ranked_list: List[RankedOpportunity]    = []
    discarded_list: List[DiscardedOpportunity] = []
    failed_list: List[FailedOpportunity]    = []

    for idx, email_text in enumerate(request.emails):
        snippet = email_text[:120].strip().replace("\n", " ") + "…"

        # ── Step 1: LLM extraction ────────────────────────────────────────
        extracted_data = extract_opportunity(email_text)

        if extracted_data is None:
            failed_list.append(FailedOpportunity(
                id=idx,
                reason="LLM failed to produce valid JSON after 3 attempts",
                snippet=snippet,
            ))
            continue

        # ── Step 2: Not an opportunity? ───────────────────────────────────
        if not extracted_data.get("is_opportunity", False):
            discarded_list.append(DiscardedOpportunity(
                id=idx,
                reason="Classified as non-opportunity by LLM",
                snippet=snippet,
            ))
            continue

        # ── Step 3: Schema validation ─────────────────────────────────────
        try:
            opp = ExtractedOpportunity(**extracted_data)
        except (ValidationError, TypeError) as exc:
            failed_list.append(FailedOpportunity(
                id=idx,
                reason=f"Schema validation failed: {exc}",
                snippet=snippet,
            ))
            continue

        # ── Step 4: Hard disqualifiers ────────────────────────────────────
        is_disqualified, disq_reason = check_hard_disqualifiers(request.profile, opp)
        if is_disqualified:
            discarded_list.append(DiscardedOpportunity(
                id=idx,
                reason=f"INELIGIBLE — {disq_reason}",
                snippet=snippet,
            ))
            continue

        # ── Step 5: Deterministic scoring ────────────────────────────────
        score_breakdown = score_opportunity(request.profile, opp, raw_email_body=email_text)

        # ── Step 6: Checklist ─────────────────────────────────────────────
        checklist = generate_checklist(opp)

        # ── Step 7: Urgency badge ─────────────────────────────────────────
        deadline_iso = normalize_date(opp.deadline_raw)
        urgency_badge = get_urgency_badge(score_breakdown.urgency.score)

        ranked_opp = RankedOpportunity(
            id=idx,
            title=opp.title or "Unknown Opportunity",
            org=opp.org or "Unknown Organization",
            type=opp.type or "other",
            deadline_iso=deadline_iso,
            urgency_badge=urgency_badge,
            score_breakdown=score_breakdown,
            checklist=checklist,
            link=opp.link,
            contact=opp.contact,
        )
        ranked_list.append(ranked_opp)

    # ── Sort by total score descending ────────────────────────────────────
    ranked_list.sort(key=lambda x: x.score_breakdown.total, reverse=True)

    return ProcessResponse(
        ranked_opportunities=ranked_list,
        discarded=discarded_list,
        failed=failed_list,
    )

# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
