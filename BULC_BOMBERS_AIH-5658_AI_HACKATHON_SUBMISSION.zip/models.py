from pydantic import BaseModel, Field
from typing import List, Optional

class StudentProfile(BaseModel):
    degree: str
    semester: int
    cgpa: float
    skills: List[str]
    preferred_opportunity_types: List[str]
    location_preference: str
    financial_need: bool

class ProcessRequest(BaseModel):
    profile: StudentProfile
    emails: List[str]

class ExtractedOpportunity(BaseModel):
    is_opportunity: bool
    type: Optional[str] = None
    title: Optional[str] = None
    org: Optional[str] = None
    deadline_raw: Optional[str] = None
    eligibility: Optional[List[str]] = []
    required_docs: Optional[List[str]] = []
    link: Optional[str] = None
    contact: Optional[str] = None
    min_cgpa: Optional[float] = None
    mandatory_language: Optional[str] = None
    degree_restrictions: Optional[List[str]] = []
    graduation_year_restriction: Optional[int] = None
    location: Optional[str] = None
    is_scholarship_or_grant: Optional[bool] = False

class ScoreDetail(BaseModel):
    score: int
    reason: str

class ScoreBreakdown(BaseModel):
    skill_alignment: ScoreDetail
    urgency: ScoreDetail
    type_match: ScoreDetail
    location: ScoreDetail
    financial_bonus: ScoreDetail
    completeness: ScoreDetail
    total: int

class ActionChecklist(BaseModel):
    task: str
    done: bool = False

class RankedOpportunity(BaseModel):
    id: int
    title: str
    org: str
    type: str
    deadline_iso: Optional[str] = None
    urgency_badge: str
    score_breakdown: ScoreBreakdown
    checklist: List[ActionChecklist]
    link: Optional[str] = None
    contact: Optional[str] = None

class DiscardedOpportunity(BaseModel):
    id: int
    reason: str
    snippet: str

class FailedOpportunity(BaseModel):
    id: int
    reason: str
    snippet: str

class ProcessResponse(BaseModel):
    ranked_opportunities: List[RankedOpportunity]
    discarded: List[DiscardedOpportunity]
    failed: List[FailedOpportunity]
